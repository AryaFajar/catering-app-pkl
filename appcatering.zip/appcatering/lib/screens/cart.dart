import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class UserCart extends StatelessWidget {
  const UserCart({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        title: Text(
          "My Cart",
          style: GoogleFonts.inter(
            color: Colors.black,
            fontSize: 20.0,
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: Colors.black,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Column(children: [
        Expanded(child: ListView.builder(itemBuilder: (context, index){
          return ListTile(
            title: Text('Item'),
          );
        }))
      ],
      ),
    );
  }
}
